<?php
session_start();
if ($_SESSION['log-py']!="allow") {
    header("Location:index.php");
}
unset($_SESSION['log-app']);
unset($_SESSION['log-web']);

$name = $_SESSION['username'];
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>vec</title>
        <link rel="stylesheet" href="assets/css/styles.css">

        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
        <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    </head>

    <body background="assets/img/bsa.svg">
        <center>
            <section style="margin-top: 1%;">
                <img src="assets/img/veclogo.gif" style="width: 100px;height: 100px;">
                <h1 class="display-4 text-center" id="head-text" style="font-size: 60px;color: black">Velammal Engineering College&nbsp;</h1>
            </section>
        </center>
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <p style="margin-top: 200px;font-size: 60px;font-weight: 700;color: black">Learn how to Code with Python
                            <br>
                        </p>
                        <p style="margin-top: 20px;font-size: 28px;color: grey;">Welcome
                            <?php echo "$name";?>
                        </p>
                    </div>
                    <div class="col-md-6"><img src="assets/img/coding_SVG.svg" style="margin-top: 10px;" width="80%"></div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <div class="container">
            <center>
                <h1>Begin Course</h1>
            </center><br><br>
            <!--card1-->
            <div class="card shadow mb-5 bg-white rounded" id="py-day1">
                <div class="row ">
                    <div class="col-md-9">
                        <br>

                        <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 1</h6>
                        <h4 style="font-family:Ubuntu; margin-left:10px;">Fundamentals of Python</h4>
                        <div class="card-block">
                            <p class="lead" style=" margin-left:10px;">Familiarize yourself with the building blocks of python!. Learn the basics of datatypes and keywords in python.</p>
                            <a href="python-day1-module1.php" class="start-button"> <img src="assets/img/button.png" class="start-img" alt="" width="70px" height="30px"> </a>
                            <hr>
                            <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 25mins</p>
                        </div>
                    </div>
                    <div class="col-md-3 d-none d-lg-block">
                        <img src="assets/img/python1.png" alt="" class="w-100 h-100">
                    </div>

                </div>
            </div>
            <!--card1-->

            <!--card2-->
            <div class="card shadow mb-5 bg-white rounded" id="py-day2">
                <div class="row ">
                    <div class="col-md-9">
                        <br>
                        <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 2</h6>
                        <h4 style="font-family:Ubuntu; margin-left:10px;">Functions in Python</h4>
                        <div class="card-block">
                            <p class="lead" style=" margin-left:10px;">Learn about operator,built-in function, mathematical and also user defined function. Understand how to improve and reuse code with functions.</p>
                            <a href="python-day2-module1.php" class="start-button"> <img src="assets/img/button.png" class="start-img" alt="" width="70px" height="30px"> </a>
                            <hr>
                            <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 30 mins</p>
                        </div>
                    </div>
                    <div class="col-md-3 d-none d-lg-block" id="py-day2">
                        <img src="assets/img/python2.png" alt="" class="w-100 h-100">
                    </div>

                </div>
            </div>
            <!--card2-->

            <!--card3-->
            <div class="card shadow mb-5 bg-white rounded" id="py-day3">
                <div class="row ">
                    <div class="col-md-9">
                        <br>
                        <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 3</h6>
                        <h4 style="font-family:Ubuntu; margin-left:10px;">Control Flow and Strings</h4>
                        <div class="card-block">
                            <p class="lead" style=" margin-left:10px;">Build logic into your code with control flow tools! Learn about conditional statement and repeating code with loops. Get familiar with the concepts of String.</p>
                            <a href="python-day3-module1.php" class="start-button"> <img src="assets/img/button.png" class="start-img" alt="" width="70px" height="30px"> </a>
                            <hr>
                            <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 40 mins</p>
                        </div>
                    </div>
                    <div class="col-md-3 d-none d-lg-block" id="day4">
                        <img src="assets/img/python3.png" alt="" class="w-100 h-100">
                    </div>

                </div>
            </div>
            <!--card3-->

            <!--card4-->
            <div class="card shadow  mb-5 bg-white rounded" id="py-day4">
                <div class="row ">
                    <div class="col-md-9">
                        <br>
                        <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 4</h6>
                        <h4 style="font-family:Ubuntu; margin-left:10px;">Data Structure</h4>
                        <div class="card-block">
                            <p class="lead" style=" margin-left:10px;">Use data structure to order and group different data types together! Get to know more about List,Tuples,Dictionary and Mapping in python.</p>
                            <a href="python-day4-module1.php" class="start-button"> <img src="assets/img/button.png" class="start-img" alt="" width="70px" height="30px"> </a>
                            <hr>
                            <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 30 mins</p>
                        </div>
                    </div>
                    <div class="col-md-3 d-none d-lg-block">
                        <img src="assets/img/python4.png" alt="" class="w-100 h-100">
                    </div>

                </div>
            </div>
            <!--card4-->

            <!--card5-->
            <div class="card shadow mb-5 bg-white rounded" id="py-day5">
                <div class="row ">
                    <div class="col-md-9">
                        <br>
                        <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 5</h6>
                        <h4 style="font-family:Ubuntu; margin-left:10px;">Packages and Exception Handling</h4>
                        <div class="card-block">
                            <p class="lead" style=" margin-left:10px;">Learn how to create and import packages and also handling the Exception.The built-in exception classes can be subclassed to define new exceptions; programmers are encouraged to derive new exceptions from the Exception class or one of its subclasses, and not from BaseException</p>
                            <a href="python-day5-module1.php" class="start-button"> <img src="assets/img/button.png" class="start-img" alt="" width="70px" height="30px"> </a>
                            <hr>
                            <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 20 mins</p>
                        </div>
                    </div>
                    <div class="col-md-3 d-none d-lg-block">
                        <img src="assets/img/python5.png" alt="" class="w-100 h-100">
                    </div>

                </div>
            </div>
            <!--card5-->

        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="script-day1.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        
    </body>

    </html>
 