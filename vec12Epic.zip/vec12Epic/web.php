<?php
session_start();

if ($_SESSION['log-web']!="allow") {
    header("Location:index.php");
}
unset($_SESSION['log-app']);
unset($_SESSION['log-py']);

$name = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>vec</title>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Off-Canvas-Sidebar-Drawer-Navbar.css">
</head>

<body background="assets/img/bsa.svg">
    <center>
    <section style="margin-top: 2%;">
        <img src="assets/img/veclogo.gif" style="width: 100px;height: 100px;">
        <h1 class="display-4 text-center" id="head-text" style="font-size: 60px;color: black">Velammal Engineering College&nbsp;</h1>
    </section>
    </center>
    <div style="margin-top: 10%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p style="margin-top: 200px;font-size: 60px;font-weight: 700;color: black">Build a Simple Webpage<br></p>
                    <p style="margin-top: 20px;font-size: 28px;color: grey;">Welcome
                        <?php echo "$name";?></p>
                    <p style="font-size: 20px;margin-top: 20px;">Learn how to build a Simple Webpage with Html , CSS , Js and PhP</p></div>
                <div
                    class="col-md-6"><img src="assets/img/web.svg" style="margin-top: 10px;" width="80%";></div>
        </div>
    </div>
    </div>
    <br>
    <br>
    <div class="container">
      <!--card1-->
      <center>
                <h1>Begin Course</h1>
            </center><br><br>
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                    <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 1</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">HTML</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Set up your development Environment for writing HTML and learn Basic tags and Syntax.</p>
                         <a href="web-day1-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 25mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/web1.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
            <!--card1-->

            <!--card2-->
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                  <br>
                   <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 2</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">CSS</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Learn the basic of CSS syntax and get started adding style to your websites.</p>
                         <a href="web-day2-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 30 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/web2.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
            <!--card2-->

            <!--card3-->
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                   <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 3</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">MySQL</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Start learning SQL by using create, insert, select, update, alter statements to read and write data in database table.</p>
                         <a href="web-day3-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 40 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/web3.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
           <!--card3-->

           <!--card4-->
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                   <br>
                    <h6 style="font-family:Ubuntu;  margin-left:10px;">Lesson 4</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">PHP</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">This Lesson provides a introduction to API's, JSOUP and HTML parsing and also scraping.</p>
                         <a href="web-day4-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 30 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/web4.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
            <!--card4-->

           <!--card5-->
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                   <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 5</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">Building a Website</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Create a simple login form with backend and also blogs.</p>
                         <a href="web-day5-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 20 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/web5.png" alt="" class="w-100 h-100">
                  </div>

                </div>
        </div>
        <!--card5-->


    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Off-Canvas-Sidebar-Drawer-Navbar.js"></script>
    <script src="assets/js/Off-Canvas-Sidebar-Drawer-Navbar-1.js"></script>
</body>

</html>
