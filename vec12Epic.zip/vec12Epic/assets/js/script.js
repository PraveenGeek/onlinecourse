var flag = "dark";

function dark() {
    if (flag == "dark") {
        document.body.style.backgroundImage = "url('assets/img/bsa2.png')";
        document.getElementById('head-text').style.color = "rgb(170,170,170)";
        document.getElementById('list-text1').style.color = "rgb(170,170,170)";
        document.getElementById('list-text2').style.color = "rgb(170,170,170)";

        document.getElementById('list-group-item').style.backgroundColor = "rgb(50,56,62)";
        document.getElementById('list-group-item2').style.backgroundColor = "rgb(50,56,62)";
        document.getElementById('list-group-item3').style.backgroundColor = "rgb(50,56,62)";
        document.getElementById('list-group-item4').style.backgroundColor = "rgb(50,56,62)";
        document.getElementById('list-group-item5').style.backgroundColor = "rgb(50,56,62)";
        document.getElementById('list-group-item6').style.backgroundColor = "rgb(50,56,62)";

        flag = "light";

    } else {
        document.body.style.backgroundImage = "url('assets/img/bsa.svg')";
        document.getElementById('head-text').style.color = "rgb(0,0,0)";
        document.getElementById('list-text1').style.color = "rgb(0,0,0)";
        document.getElementById('list-text2').style.color = "rgb(0,0,0)";

        document.getElementById('list-group-item').style.backgroundColor = "inherit";
        document.getElementById('list-group-item2').style.backgroundColor = "inherit";
        document.getElementById('list-group-item3').style.backgroundColor = "inherit";
        document.getElementById('list-group-item4').style.backgroundColor = "inherit";
        document.getElementById('list-group-item5').style.backgroundColor = "inherit";
        document.getElementById('list-group-item6').style.backgroundColor = "inherit";

        flag = "dark";
    }
}
function enable(){
    document.getElementById('#py-day2').visibility = "visible";

}