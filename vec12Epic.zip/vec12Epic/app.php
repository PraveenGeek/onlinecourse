<?php

session_start();
if ($_SESSION['log-app']!="allow") {
    header("Location:index.php");
}
unset($_SESSION['log-web']);
unset($_SESSION['log-py']);

$name = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>vec</title>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Off-Canvas-Sidebar-Drawer-Navbar.css">
</head>

<body background="assets/img/bsa.svg">
    <center>
    <section style="margin-top: 2%;">
        <img src="assets/img/veclogo.gif" style="width: 100px;height: 100px;">
        <h1 class="display-4 text-center" id="head-text" style="font-size: 60px;color: black">Velammal Engineering College&nbsp;</h1>
    </section>
    </center>
    <div style="margin-top: 10%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p style="margin-top: 200px;font-size: 60px;font-weight: 700;color: black">Build a Simple Android app<br></p>
                    <p style="margin-top: 20px;font-size: 28px;color: grey;">Welcome
                        <?php echo "$name";?></p>
                    <p style="font-size: 20px;margin-top: 20px;">Learn how to build a Simple android app with android studio and firebase</p></div>
                <div
                    class="col-md-6"><img src="assets/img/app.png" style="margin-top: 10px;width:100%;"></div>
        </div>
    </div>
    </div>
    <!--<div class="card" style="padding: 60px;margin: 5%;">
        <div class="card-body border rounded shadow">
            <a href="app-day1-module1.php" style="text-decoration: none">
            <h4 class="card-title">Java Basics<br></h4>
            <h6 class="text-muted card-subtitle mb-2">Minutes : 25</h6>
            </a>
        </div>
        <div class="card-body border rounded shadow" style="margin-top: 4%;">
            <a href="app-day2-module1.php" style="text-decoration: none">
            <h4 class="card-title">Intro to Android environment<br></h4>
            <h6 class="text-muted card-subtitle mb-2">Minute : 30</h6>
            </a>
        </div>
        <div class="card-body border rounded shadow" style="margin-top: 4%;">
            <a href="app-day3-module1.php" style="text-decoration: none">
            <h4 class="card-title">Android Basics<br></h4>
            <h6 class="text-muted card-subtitle mb-2">Minutes : 60</h6>
            </a>
        </div>
        <div class="card-body border rounded shadow" style="margin-top: 4%;">
            <a href="app-day4-module1.php" style="text-decoration: none">
            <h4 class="card-title">Webscraping with android<br></h4>
            <h6 class="text-muted card-subtitle mb-2">Minutes : 90</h6>
            </a>
        </div>
        <div class="card-body border rounded shadow" style="margin-top: 4%;">
            <a href="app-day5-module1.php" style="text-decoration: none">
            <h4 class="card-title">Firebase<br></h4>
            <h6 class="text-muted card-subtitle mb-2">Minutes : 80</h6>
            </a>
        </div>
    </div>-->
    <br>
    <br>
    <div class="container">
      <center>
                <h1>Begin Course</h1>
            </center><br><br>
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9 ">
                    <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 1</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">Java Basics</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">This Lesson provides an introduction java and object oriented programming and also explains how to use classes and objects in java.</p>
                         <a href="app-day1-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 25mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/android1.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                  <br>
                   <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 2</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">Android Environment</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Installation and Setup of Android Studio and also basic Frontend XML, Backend Java.</p>
                         <a href="app-day2-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 30 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/android2.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
        <div class="card shadow  mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9 ">
                   <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 3</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">Android Basics</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">Creating Simple login form and also Importing a website into android app.</p>
                         <a href="app-day3-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 40 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/android3.png" alt="" class="w-100 h-100">
                  </div>
              </div>
            </div>

        <div class="card shadow mb-5 bg-white rounded">
          <div class="row ">
              <div class="col-md-9">
                   <br>
                    <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 4</h6>
                    <h4 style="font-family:Ubuntu; margin-left:10px;">Webscraping with android</h4>
                    <div class="card-block">
                         <p class="lead" style=" margin-left:10px;">This Lesson provides a introduction to API's, JSOUP and HTML parsing and also scraping.</p>
                         <a href="app-day4-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                         <hr>
                         <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 30 mins</p>
                    </div>
                  </div>
                  <div class="col-md-3 d-none d-lg-block">
                    <img src="assets/img/android4.png" alt="" class="w-100 h-100">
                  </div>

                </div>
            </div>
        <div class="card shadow mb-5 bg-white rounded">
          <div class="row">
            <div class="col-md-9 ">
                 <br>
                  <h6 style="font-family:Ubuntu; margin-left:10px;">Lesson 5</h6>
                  <h4 style="font-family:Ubuntu; margin-left:10px;">Firebase</h4>
                  <div class="card-block">
                       <p class="lead" style=" margin-left:10px;">Understanding Firebase's Realtime Database and Firestore. Build an application to upload and retrieve data from cloud server.</p>
                       <a href="app-day5-module1.php" class="start-button">  <img src="assets/img/button.png" class="start-img"alt="" width="70px" height="30px"> </a>
                       <hr>
                       <p class="lead float-right"><i class="fa fa-clock-o" aria-hidden="true"></i>&nbsp 1 hour 20 mins</p>
                  </div>
                </div>
                <div class="col-md-3 d-none d-lg-block">
                  <img src="assets/img/android5.png" alt="" class="w-100 h-100">
                </div>
          </div>


            </div>
      </div>

    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Off-Canvas-Sidebar-Drawer-Navbar.js"></script>
    <script src="assets/js/Off-Canvas-Sidebar-Drawer-Navbar-1.js"></script>
</body>

</html>
